package com.example.employeejavafx;

import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.util.ArrayList;

public class employeeController {
    private static ArrayList<employeedata> info = new ArrayList<>();
    @FXML
    TextField input_name;
    @FXML
    TextField input_gender;
    @FXML
    TextField input_age;
    @FXML
    TextField input_id;
    @FXML
    TextField input_salary;
    @FXML
    Label label_message;
    @FXML
    protected void OnSubmitButton(Event e){
        if(input_name.getText().length()>0 && input_age.getText().length()>0) {
            employeedata u = new employeedata();
            u.name = input_name.getText();
            u.gender=input_gender.getText();
            u.age = Integer.parseInt(input_age.getText());
            u.id= Integer.parseInt(input_id.getText());
            u.salary=Integer.parseInt(input_salary.getText());
            info.add(u);
            label_message.setText("Information is Added!");
        }else{
            System.out.println("please Fill in the Information");
        }
    }
    @FXML
    protected void OnListButton(Event e){
        System.out.println("=====Employee Information=====");
        for (employeedata u: info) {
            System.out.println("Name: " +u.name);
            System.out.println("Gender: " +u.gender);
            System.out.println("Age: " +u.age);
            System.out.println("ID: " +u.gender);
            System.out.println("Salary: " +u.salary);
        }
    }
}

